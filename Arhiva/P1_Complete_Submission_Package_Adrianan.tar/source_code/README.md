# QFLPN Paper 1: Formal Operator Semantics Source Code Repository
**Author:** Adrian Roman (Technical University of Cluj-Napoca, Romania)  
**Journal Target:** *Information Fusion* (Elsevier)  

## Contents
This comprehensive archive contains the complete, integral source code for Paper 1:
- `p1_worked_examples.py`: Section 13 worked examples, CPTP Kraus evolution, trace distance.
- `p1_worked_results.json`: Archived numerical results.
- `test_p1_formalism.py`: Complete test suite for all 13 core formalism hypotheses.
- `repo_baseline/`: Full multi-file repository structure (artifacts, benchmarks, code, reports, tests, tools).
- `verify_all_outputs.py`: Unified reproducibility validation script.
- `QFLPN_Reproduction_Registry.md`: Master registry.
