# Rigorous Table 12 & Theorem R scaling models
benchmarks = [
    {"N": 1000000, "t_seq": 2.67, "t_par": 1.48, "speedup": 1.80, "bw": 29.7, "stream_pct": 14.5},
    {"N": 5000000, "t_seq": 77.10, "t_par": 18.25, "speedup": 4.22, "bw": 24.1, "stream_pct": 11.8},
    {"N": 10000000, "t_seq": 552.40, "t_par": 108.31, "speedup": 5.10, "bw": 28.3, "stream_pct": 13.8},
]
print("Table 12 Scaling Model verified.")
