# QFLPN Paper 3: Sparse Numerical Evolution Source Code Repository
**Author:** Adrian Roman (Technical University of Cluj-Napoca, Romania)  
**Journal Target:** *Information Fusion* (Elsevier)  

## Strictly Discrete Marking State Space (NO QUBITS)
Paper 3 addresses exclusively discrete Petri net marking state spaces ($N = 10^6 \dots 3 \times 10^8$) evolved via Compressed Sparse Row (CSR) matrix-vector multiplication.

## Contents
- `spmv_csr_kernel.c`: OpenMP C SpMV kernel with guided workstealing.
- `stream_triad.c`: Sustained memory bandwidth benchmark.
- `compensated_summation.c`: Kahan compensated summation kernel.
- `model_scaling_p3.py`: Rigorous Table 12 dual AMD EPYC 7763 scaling model & Theorem R Roofline model ($I = 1/11$ FLOP/Byte).
- `run_eosc_664.slurm`: Slurm script for 16 nodes, 664 cores on European Open Science Cloud (EOSC).
- `repo_baseline/`: Complete author repository baseline (Java ParallelSpmvHarness, benchmarks, tests, reports).
- `Makefile`: Build instructions.
- `verify_all_outputs.py`: Master verification script.
- `QFLPN_Reproduction_Registry.md`: Master registry.
