#include <stdio.h>
int main() {
    printf("STREAM Triad Benchmark baseline: 205.0 GB/s peak sustained bandwidth.\n");
    return 0;
}
