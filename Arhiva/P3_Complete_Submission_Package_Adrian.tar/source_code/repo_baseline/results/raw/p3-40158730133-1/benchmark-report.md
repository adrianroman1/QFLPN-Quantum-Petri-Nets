## QFLPN P3 benchmark summary

- Validation: **PASS**
- Run ID: `p3-40158730133-1`
- Schema: `qflpn-benchmark-v2`
- Valid CSV records: 17
- Dimension: 1000000
- Non-zero values: 2000000
- Warm-up iterations: 5
- Measured iterations: 10

| Metric | Sequential | Parallel |
|---|---:|---:|
| Mean (ms) | 3.685679 | 10.365866 |
| Median (ms) | 2.722930 | 9.909714 |
| Std. dev. (ms) | 1.206276 | 1.469081 |
| Throughput (states/s) | 271320390.175 | 96470473.379 |

- Speedup: **0.355559×**
- Sequential oracle error: `0.000000000000e+00`
- Parallel oracle error: `0.000000000000e+00`
- Maximum absolute error: `0.000000000000e+00`
- JSON report: `/home/runner/work/QFLPN-Quantum-Petri-Nets/QFLPN-Quantum-Petri-Nets/P3/results/raw/p3-40158730133-1/validation-report.json`
- CSV evidence: `/home/runner/work/QFLPN-Quantum-Petri-Nets/QFLPN-Quantum-Petri-Nets/P3/benchmarks/benchmark_results_v2.csv`

The CSV row and JSON validation report were matched by the exact RUN_ID.
