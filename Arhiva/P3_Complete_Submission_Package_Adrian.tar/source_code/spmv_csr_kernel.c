#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void spmv_csr_openmp(int N, const int* row_ptr, const int* col_ind, const double* val, const double* x, double* y) {
    #pragma omp parallel for schedule(guided)
    for (int i = 0; i < N; i++) {
        double sum = 0.0;
        int row_start = row_ptr[i];
        int row_end = row_ptr[i + 1];
        for (int j = row_start; j < row_end; j++) {
            sum += val[j] * x[col_ind[j]];
        }
        y[i] = sum;
    }
}

int main(int argc, char** argv) {
    int N = 1000000;
    printf("QFLPN P3 High-Performance SpMV CSR Kernel\n");
    printf("N = %d discrete markings (NO QUBITS)\n", N);
    return 0;
}
