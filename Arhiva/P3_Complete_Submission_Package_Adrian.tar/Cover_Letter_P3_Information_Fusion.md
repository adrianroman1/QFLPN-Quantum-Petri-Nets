# Cover Letter — Information Fusion (Elsevier, Q1)
## Manuscript P3: Sparse Numerical Evolution for Quantum-Fuzzy Logical Petri Nets: A Parallel Benchmark

**To:** Prof. Francisco Herrera, Editor-in-Chief  
*Information Fusion*, Elsevier  
**Date:** 10 November 2026  
**Corresponding Author:** Adrian Roman (`adrianroman304@gmail.com` / `adrian.roman@campus.utcluj.ro`)  
**Affiliation:** Faculty of Automation and Computer Science, Technical University of Cluj-Napoca (UTCN), Romania  

---

Dear Editor-in-Chief and Editorial Board of *Information Fusion*,

We are pleased to submit our original research manuscript entitled:  
**"Sparse Numerical Evolution for Quantum-Fuzzy Logical Petri Nets: A Parallel Benchmark"**  
for consideration as a regular paper in *Information Fusion*.

In strict compliance with the **Guide for Authors of Information Fusion**, we provide below the direct responses to the **Seven Mandatory Editorial Desk Screening Questions**:

### 1. State of the art with 5 recent references
1. Vuduc, R. W., Demmel, J. W. et al., "Performance Optimizations and Bounds for Sparse Matrix-Vector Multiply," *Proceedings of the ACM/IEEE Conference on Supercomputing (SC)*, 2002.
2. Williams, S., Oliker, L., Vuduc, R., Shalf, J., Yelick, K., and Demmel, J., "Optimization of sparse matrix--vector multiplication on emerging multicore platforms," *Parallel Computing*, vol. 35, no. 3, pp. 178–194, 2009.
3. Davis, T. A., "Algorithm 1000: SuiteSparse:GraphBLAS: Graph Algorithms in the Language of Sparse Linear Algebra," *ACM Transactions on Mathematical Software*, vol. 45, no. 4, art. 44, 2019.
4. Hoefler, T. and Belli, R., "Scientific benchmarking of parallel computing systems: Twelve ways to tell the masses when reporting performance results," in *Proc. ACM/IEEE SC '15*, art. 73, 2015.
5. Dongarra, J., Heroux, M. A., and Luszczek, P., "High-performance conjugate-gradient benchmark: A new metric for ranking high-performance computing systems," *IJHPCA*, vol. 30, no. 1, pp. 3–10, 2016.

### 2. Benchmark datasets / instances used
- Large-scale numerical state evolution on Compressed Sparse Row (CSR) matrices.
- Discrete state space scaling across 5 problem orders: $N = 10^6, 10^7, 7\times 10^7, 10^8$, and up to $N = 300,000,000$ states ($NNZ = 600,000,000$, occupying 12.29 GiB RAM total).
- Three declared sparse structures: (a) quantum gate operator, (b) uniform random columns, (c) skewed row lengths testing load imbalance metric $B$.

### 3. Validation measures
- Roofline performance model: operational intensity $I = \frac{2\cdot NNZ}{12\cdot NNZ + 20N} \approx 0.0909\text{ FLOP/byte}$, proving memory-bandwidth bound regime.
- Measured sustained bandwidth $B_{\mathrm{eff}}$ (GB/s) and percentage of sustained STREAM triad bandwidth ($12.43\text{ GB/s}$ single-core, $204.8\text{ GB/s}$ multi-channel HPC node).
- Numerical correctness validated with Neumaier compensated summation (Algorithm 3) with absolute error bounded by $1.8\times 10^{-15}$.

### 4. Principal original claim
The principal original contribution is the **traceable numerical separation between quantum state registers and massive discrete state-space evolution**. We show that large-scale QFLPN state spaces do not require exponential qubit interpretations, and formulate an OpenMP/CSR SpMV parallelization scheme with rigorous Proposition S ceiling bounds that prevents false superlinear efficiency claims.

### 5. Concrete evidence provided
- Complete multi-threaded performance model scaling (Table 12) showing parallel speedup up to $5.37\times$ at $N=10^8$.
- Rigorous roofline analysis matching empirical measurements.
- Complete OpenMP C and Python sources archived under persistent DOI: `10.5281/zenodo.10823481`.

### 6. Closely related prior works
Prior QPN simulations conflated discrete token markings with quantum amplitudes or reported unaudited speedups without specifying task thresholds or cache-resident effects.

### 7. Prior publications declaration
The authors declare that this work is original, has not been published previously, and is not submitted elsewhere.

---

Sincerely,  
**Adrian Roman**, MSc / PhD Candidate  
Faculty of Automation and Computer Science, UTCN, Romania  
Email: `adrianroman304@gmail.com` / `adrian.roman@campus.utcluj.ro`
