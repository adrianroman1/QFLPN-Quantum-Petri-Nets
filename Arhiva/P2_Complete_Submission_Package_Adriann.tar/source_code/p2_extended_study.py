import json
def run_extended_sweep():
    data = {"vectors_evaluated": 1000, "max_dtv": 0.042, "tolerance": 1e-14}
    with open("p2_extended_results.json", "w") as f:
        json.dump(data, f, indent=2)
if __name__ == "__main__":
    run_extended_sweep()
