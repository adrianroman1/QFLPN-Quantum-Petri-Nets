# QFLPN Paper 2: Four-Qubit Reference Instance Source Code Repository
**Author:** Adrian Roman (Technical University of Cluj-Napoca, Romania)  
**Journal Target:** *Information Fusion* (Elsevier)  

## Contents
- `p2_verify.py`: Standard library verifier reproducing the reference state and Meyer-Wallach Q = 0.0809.
- `p2_extended_study.py`: 1,000-vector Monte Carlo sweep.
- `recompute_variants.py`: Table 9 and 10 gate convention and tensor ordering sweep.
- `p2_pennylane_extension.py`: Independent PennyLane simulation and 28-qubit memory scaling envelope.
- `repo_baseline/`: Complete author repository baseline (tests, benchmarks, artifacts, reports).
- `verify_all_outputs.py`: Global verification script.
- `QFLPN_Reproduction_Registry.md`: Master registry.
