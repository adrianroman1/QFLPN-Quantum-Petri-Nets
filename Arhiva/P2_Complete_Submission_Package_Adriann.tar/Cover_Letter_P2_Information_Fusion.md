# Cover Letter — Information Fusion (Elsevier, Q1)
## Manuscript P2: A Four-Qubit Reference Instance of Quantum-Fuzzy Logical Petri Nets

**To:** Prof. Francisco Herrera, Editor-in-Chief  
*Information Fusion*, Elsevier  
**Date:** 10 November 2026  
**Corresponding Author:** Adrian Roman (`adrianroman304@gmail.com` / `adrian.roman@campus.utcluj.ro`)  
**Affiliation:** Faculty of Automation and Computer Science, Technical University of Cluj-Napoca (UTCN), Romania  

---

Dear Editor-in-Chief and Editorial Board of *Information Fusion*,

We are pleased to submit our original research manuscript entitled:  
**"A Four-Qubit Reference Instance of Quantum-Fuzzy Logical Petri Nets"**  
for consideration as a regular research article in *Information Fusion*.

In strict compliance with the **Guide for Authors of Information Fusion**, we provide below the direct responses to the **Seven Mandatory Editorial Desk Screening Questions**:

### 1. State of the art with 5 recent references
1. Vallero, M., Rech, P., and Vella, F., "State of Practice: Evaluating GPU Performance of State Vector and Tensor Network Methods," *Future Generation Computer Systems*, vol. 174, art. 107927, 2026.
2. Pastor, A. M., Badia, J. M., and Castillo, M., "A community detection-based parallel algorithm for quantum circuit simulation using tensor networks," *The Journal of Supercomputing*, vol. 81, art. 450, 2025.
3. Letia, T. S. et al., "Development of Evolutionary Systems Based on Quantum Petri Nets," *Mathematics*, vol. 10, no. 23, art. 4404, 2022.
4. Deng, Y. et al., "Quantum Evidence Theory and Information Fusion," *Information Fusion*, vol. 92, pp. 102–118, 2023.
5. Bouwmeester, D., Pan, J.-W., Mattle, K., Eibl, M., Weinfurter, H., and Zeilinger, A., "Experimental quantum teleportation," *Nature*, vol. 390, pp. 575–579, 1997.

### 2. Benchmark datasets / instances used
- Fully declared, deterministic 4-qubit reference system ($N=16$ basis states $|0000\rangle \dots |1111\rangle$).
- Cross-validated against Qiskit Aer and PennyLane 0.35 simulators.
- Resource scalability envelope extending up to a 28-qubit register ($N = 2^{28} = 268,435,456$ state amplitudes, 4.00 GiB single vector, 8.00 GiB dual vector).

### 3. Validation measures
- Squared state fidelity: $F(\rho_{\mathrm{declared}}, \rho_{\mathrm{target}})$.
- Total variation distance: $D_{\mathrm{TV}} = \frac{1}{2}\sum |p_i - q_i|$.
- Meyer-Wallach multipartite entanglement measure: $Q = 0.0809$ across 1,001 tested configurations.
- Von Neumann entropy across all 7 bipartite state cuts: $\{q_0\}\{q_1q_2q_3\}$, $\{q_1\}\{q_0q_2q_3\}$, $\{q_2\}\{q_0q_1q_3\}$, $\{q_3\}\{q_0q_1q_2\}$, $\{q_0q_1\}\{q_2q_3\}$, $\{q_0q_2\}\{q_1q_3\}$, $\{q_0q_3\}\{q_1q_2\}$.

### 4. Principal original claim
The manuscript provides the **first complete, closed-form deterministic four-qubit reference benchmark** for quantum-fuzzy Petri nets. We prove analytically that target-qubit assignment and endianness conventions create significant variations ($F$ ranging from 0.8807 to 1.0000, and $D_{\mathrm{TV}}$ up to 0.283050 for target $q_2$), establishing a definitive calibration instance for all subsequent quantum Petri net research.

### 5. Concrete evidence provided
- Exact analytical match in Table 8 ($F=0.897560, D_{\mathrm{TV}}=0.283050$).
- PennyLane and Qiskit verification circuits yielding maximum absolute error below $2.3\times 10^{-15}$.
- Open archive deposit with persistent DOI: `10.5281/zenodo.10823480`.

### 6. Closely related prior works
Prior quantum Petri net papers reported state vectors without documenting the exact basis ordering, little-endian vs big-endian conventions, or controlled-gate target assignments, preventing independent verification.

### 7. Prior publications declaration
The authors declare that this work is original, has not been published previously, and is not submitted elsewhere.

---

Sincerely,  
**Adrian Roman**, MSc / PhD Candidate  
Faculty of Automation and Computer Science, UTCN, Romania  
Email: `adrianroman304@gmail.com` / `adrian.roman@campus.utcluj.ro`
