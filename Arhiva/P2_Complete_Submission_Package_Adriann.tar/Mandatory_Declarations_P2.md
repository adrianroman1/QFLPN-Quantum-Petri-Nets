# Mandatory Declarations for Elsevier Submission - P2
**Article Title:** A Four-Qubit Reference Instance of Quantum-Fuzzy Logical Petri Nets  
**Journal:** *Information Fusion* (Elsevier)  
**Author:** Adrian Roman (Technical University of Cluj-Napoca, Romania)  

---

### 1. CRediT Author Statement
Adrian Roman: Conceptualization, Methodology, Software, Validation, Formal analysis, Investigation, Writing – original draft, Writing – review & editing, Visualization, Supervision, Project administration.

### 2. Declaration of Competing Interest
The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

### 3. Funding Statement
This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors.

### 4. Declaration of Generative AI and AI-Assisted Technologies
The authors declare that no generative AI tools were used in the preparation of this manuscript or in the execution of the quantum circuit simulations.

### 5. Data Availability Statement
The data and code that support the findings of this study are openly available in the QFLPN-Quantum-Petri-Nets repository at https://github.com/adrianroman1/QFLPN-Quantum-Petri-Nets under DOI: 10.5281/zenodo.10823480. The reference instance and 1,000-vector Monte Carlo sweep are reproduced by p2_verify.py and p2_extended_study.py.
